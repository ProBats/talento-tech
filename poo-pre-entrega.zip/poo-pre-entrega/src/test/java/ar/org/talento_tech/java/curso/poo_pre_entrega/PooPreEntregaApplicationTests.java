package ar.org.talento_tech.java.curso.poo_pre_entrega;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooPreEntregaApplicationTests {

	@Test
	void contextLoads() {
	}

}
