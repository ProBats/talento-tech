package ar.org.talento_tech.java.curso.entidades.articulo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Articulo {
    private String codigoDeBarras;
    private String nombre;
    private String marca;
    private String categoria;
    private float precioUnitario;
    private String unidadDeMedida;
    private int cantidad;
    private String fechaDeVencimiento;

}
