package ar.org.talento_tech.java.curso.entidades.menu;

import java.util.Scanner;

public class Metodos {
    Scanner scanner = new Scanner(System.in);

    public void mostrarMenu(){
        System.out.println("\n===== MENÚ DE ARTÍCULOS =====");
            System.out.println("1. Crear artículo");
            System.out.println("2. Modificar artículo");
            System.out.println("3. Listar artículo por posición");
            System.out.println("4. Listar todos los artículos");
            System.out.println("5. Eliminar artículo");
            System.out.println("6. Salir");
            System.out.print("Elija una opción: ");
    }

    public void crearArticulo(String[] articulos){
        // Crear artículo
        System.out.print("Ingrese el nombre del artículo: ");
        String nuevo = scanner.nextLine();

        // Validar que no esté vacío
        if (nuevo.trim().isEmpty()) {
            System.out.println("El nombre no puede estar vacío.");
            return;
        }

        // Buscar una posición libre en el array
        boolean guardado = false;
        for (int i = 0; i < articulos.length; i++) {
            if (articulos[i] == null) {
                articulos[i] = nuevo;
                System.out.println(" Artículo guardado en la posición " + i);
                guardado = true;
                return;
            }
        }

        if (!guardado) {
            System.out.println("No hay más espacio para artículos.");
        }
        return;
    }

    public void modificarArticulo(String[] articulos){
        // Modificar artículo
        System.out.print("Ingrese la posición del artículo a modificar (0-9): ");
        int posMod = scanner.nextInt();
        scanner.nextLine();

        // Validar posición
        if (posMod < 0 || posMod >= articulos.length) {
            System.out.println("Posición inválida.");
            return;
        }

        if (articulos[posMod] == null) {
            System.out.println("No hay artículo en esa posición.");
            return;
        }

        // Pedir nuevo nombre
        System.out.print("Ingrese el nuevo nombre: ");
        String modificado = scanner.nextLine();

        if (modificado.trim().isEmpty()) {
            System.out.println(" El nombre no puede estar vacío.");
            return;
        }

        articulos[posMod] = modificado;
        System.out.println(" Artículo modificado correctamente.");
        return;
    }

    public void listarArticulosPorPosicion(String[] articulos){
        // Listar artículo por posición
        System.out.print("Ingrese la posición a consultar (0-9): ");
        int posVer = scanner.nextInt();

        if (posVer < 0 || posVer >= articulos.length) {
            System.out.println("Posición inválida.");
            return;
        }

        if (articulos[posVer] == null) {
            System.out.println("No hay artículo en esa posición.");
        } else {
            System.out.println("Artículo en posición " + posVer + ": " + articulos[posVer]);
        }
        return;
    }

    public void listarArticulos(String[] articulos) {
        // Listar todos los artículos
        System.out.println("===== LISTADO DE ARTÍCULOS =====");
        for (int i = 0; i < articulos.length; i++) {
            if (articulos[i] != null) {
                System.out.println("Posición " + i + ": " + articulos[i]);
            } else {
                System.out.println("Posición " + i + ": [vacío]");
            }
        }
        return;
        }

    public void eliminarArticulos(String[] articulos){
        // Eliminar artículo
        System.out.print("Ingrese la posición del artículo a eliminar (0-9): ");
        int posDel = scanner.nextInt();

        if (posDel < 0 || posDel >= articulos.length) {
            System.out.println("Posición inválida.");
            return;
        }

        if (articulos[posDel] == null) {
            System.out.println(" No hay artículo en esa posición.");
        } else {
            articulos[posDel] = null; // Se elimina asignando null
            System.out.println("Artículo eliminado.");
        }
        return;
    }

}
