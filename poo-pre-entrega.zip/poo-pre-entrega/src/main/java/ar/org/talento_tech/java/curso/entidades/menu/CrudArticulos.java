package ar.org.talento_tech.java.curso.entidades.menu;

import java.util.Scanner;

public class CrudArticulos {
    public static void main(String[] args) {
        Metodos metodos = new Metodos();
        // ==========================
        // Declaraciones iniciales
        // ==========================

        // Array de String para almacenar hasta 10 artículos
        String[] articulos = new String[10];

        // Scanner para leer datos del usuario
        Scanner scanner = new Scanner(System.in);

        // Variable para controlar la opción del menú
        int opcion = 0;

        // ==========================
        // Bucle principal del menú
        // ==========================
        while (opcion != 6) { // se repite mientras no elija salir
            // Mostrar menú
            metodos.mostrarMenu();

            // Leer opción del usuario
            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar el buffer

            // ==========================
            // Switch para ejecutar la opción
            // ==========================
            switch (opcion) {
                case 1 -> metodos.crearArticulo(articulos);

                case 2 -> metodos.modificarArticulo(articulos);

                case 3 -> metodos.listarArticulosPorPosicion(articulos);

                case 4 -> metodos.listarArticulos(articulos);

                case 5 -> metodos.eliminarArticulos(articulos);

                case 6 -> // Salir
                    System.out.println("¡Gracias por usar el sistema!");


                default-> // Si ingresa algo fuera del 1-6
                    System.out.println("Opción inválida, intente nuevamente.");
            }
        }

        scanner.close();
    }
}
