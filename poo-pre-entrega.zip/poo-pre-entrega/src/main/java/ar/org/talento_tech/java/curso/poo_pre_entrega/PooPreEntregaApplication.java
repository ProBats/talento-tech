package ar.org.talento_tech.java.curso.poo_pre_entrega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooPreEntregaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PooPreEntregaApplication.class, args);
	}

}
